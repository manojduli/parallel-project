package com.cg.bean;

import java.util.ArrayList;
import java.util.List;

public class Bank {
	private String userName;
	private int accNo;
	private int balance;
	private static int accno = 1003;
	private List<String> list = new ArrayList<String>();
	
	
	public Bank(String userName, int accNo, int balance) {
		super();
		this.userName = userName;
		this.accNo = accNo;
		this.balance = balance;
	}
	
    public Bank() {
		super();	
	}

    
    
	@Override
	public String toString() {
		return "Bank [userName=" + userName + ", accNo=" + accNo + ", balance=" + balance + "]";
	}
	
	
	
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public int getAccNo() {
		return accNo;
	}
	public void setAccNo() {
		accNo = ++accno;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public void setBalance(){
		balance = 0;
		
	
	}

	public List<String> getList() {
		return list;
	}

	public void setList(String s) {
		list.add(s);
		this.list = list;

	}
}
