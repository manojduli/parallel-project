package com.cg.validation;
/*
 * This method is for Account number validation
 */
public class Validation {
public static void acccountValidation(int accNo){


	if(accNo >9999 || accNo<1000){
		System.out.println("*****Invalid Account Number*****");
	}
}

/* 
 * This method is for User name validation
 */
  public static boolean  userNameValidation(String UserName) {
	if(UserName.charAt(0)>=65 && UserName.charAt(0)<=90 ){
		return true;
		}
	else
	{
		System.out.println("***Enter first letter as capital***");
		return false;
	}
	
}
}

